# Shelfmark

A small storefront UI I'm messing around with on weekends -- React +
Vite, no backend yet (everything in `src/services` is mocked/local).
Product images in `src/assets/products` are placeholders until I get
around to shooting real product photography.

## Running it

```
npm install
npm run dev
```

## Structure

- `src/pages` -- route-level views
- `src/components` -- shared UI pieces
- `src/context`, `src/hooks` -- cart/auth state
- `src/services` -- fake API layer, swap for a real backend later
- `src/assets/products` -- placeholder imagery, organized by category

Nothing here is production-ready. Just a project I pick at occasionally.
