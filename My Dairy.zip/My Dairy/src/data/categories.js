export const CATEGORIES = [
  { id: 'electronics', label: 'Electronics' },
  { id: 'fashion', label: 'Fashion' },
  { id: 'home', label: 'Home & Living' },
  { id: 'sports', label: 'Sports & Outdoors' },
  { id: 'books', label: 'Books' },
];

export function categoryLabel(id) {
  const match = CATEGORIES.find((c) => c.id === id);
  return match ? match.label : id;
}
