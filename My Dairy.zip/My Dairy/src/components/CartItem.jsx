import PriceTag from './PriceTag.jsx';

export default function CartItem({ item, onRemove }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0' }}>
      <span>{item.name} x{item.qty}</span>
      <PriceTag cents={item.priceCents * item.qty} />
      <button onClick={() => onRemove(item.id)}>Remove</button>
    </div>
  );
}
