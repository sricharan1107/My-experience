import { CATEGORIES } from '../data/categories.js';

export default function FilterSidebar({ selected, onSelect }) {
  return (
    <aside style={{ minWidth: 160 }}>
      <h4>Categories</h4>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {CATEGORIES.map((c) => (
          <li key={c.id}>
            <button
              onClick={() => onSelect(c.id)}
              style={{ fontWeight: selected === c.id ? 700 : 400 }}
            >
              {c.label}
            </button>
          </li>
        ))}
      </ul>
    </aside>
  );
}
