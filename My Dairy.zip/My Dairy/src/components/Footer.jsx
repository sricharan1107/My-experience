export default function Footer() {
  return (
    <footer style={{ padding: 24, textAlign: 'center', color: '#6b7280', fontSize: 13 }}>
      shelfmark -- personal project, not a real store.
    </footer>
  );
}
