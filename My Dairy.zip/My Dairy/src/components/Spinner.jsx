export default function Spinner() {
  return <div role="status" style={{ padding: 24, textAlign: 'center' }}>Loading...</div>;
}
