import { formatCurrency } from '../utils/formatCurrency.js';

export default function PriceTag({ cents }) {
  return <strong>{formatCurrency(cents)}</strong>;
}
