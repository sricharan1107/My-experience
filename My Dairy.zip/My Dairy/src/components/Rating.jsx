export default function Rating({ value = 0, max = 5 }) {
  return (
    <div aria-label={`${value} out of ${max} stars`}>
      {'*'.repeat(value)}{'.'.repeat(max - value)}
    </div>
  );
}
