import { Link } from 'react-router-dom';
import PriceTag from './PriceTag.jsx';
import Rating from './Rating.jsx';

export default function ProductCard({ product }) {
  return (
    <div className="product-card">
      <Link to={`/products/${product.id}`}>
        <div style={{ background: '#f3f4f6', aspectRatio: '1/1', borderRadius: 6 }} />
        <h4>{product.name}</h4>
      </Link>
      <PriceTag cents={product.priceCents} />
      <Rating value={4} />
    </div>
  );
}
