import { Link } from 'react-router-dom';
import { useCart } from '../hooks/useCart.js';

export default function Navbar() {
  const { items } = useCart();
  const count = items.reduce((sum, i) => sum + i.qty, 0);

  return (
    <header style={{ borderBottom: '1px solid #e5e7eb', padding: '12px 24px', display: 'flex', justifyContent: 'space-between' }}>
      <Link to="/" style={{ fontWeight: 700, textDecoration: 'none', color: '#111' }}>shelfmark</Link>
      <nav style={{ display: 'flex', gap: 16 }}>
        <Link to="/products">Products</Link>
        <Link to="/cart">Cart ({count})</Link>
        <Link to="/login">Login</Link>
      </nav>
    </header>
  );
}
