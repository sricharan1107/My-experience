import { apiPost } from './api.js';

export async function login(email, password) {
  try {
    return await apiPost('/auth/login', { email, password });
  } catch {
    // no backend wired up yet
    return { id: 'local-dev-user', email };
  }
}

export async function register(email, password) {
  try {
    return await apiPost('/auth/register', { email, password });
  } catch {
    return { id: 'local-dev-user', email };
  }
}
