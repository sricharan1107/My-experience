import { apiGet } from './api.js';
import { CATEGORIES } from '../data/categories.js';

// Mock catalog until there's a real backend. Prices are placeholders.
function mockProducts() {
  const products = [];
  let id = 1;
  for (const cat of CATEGORIES) {
    for (let i = 1; i <= 6; i++) {
      products.push({
        id: id++,
        name: `${cat.label} item ${i}`,
        category: cat.id,
        priceCents: 1999 + i * 350,
      });
    }
  }
  return products;
}

export async function fetchProducts() {
  try {
    return await apiGet('/products');
  } catch {
    return mockProducts();
  }
}

export async function fetchProductById(id) {
  const products = await fetchProducts();
  return products.find((p) => String(p.id) === String(id)) || null;
}
