import { useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { fetchProductById } from '../services/productService.js';
import { useCart } from '../hooks/useCart.js';
import PriceTag from '../components/PriceTag.jsx';
import Spinner from '../components/Spinner.jsx';

export default function ProductDetail() {
  const { id } = useParams();
  const [product, setProduct] = useState(undefined);
  const { addItem } = useCart();

  useEffect(() => {
    fetchProductById(id).then(setProduct);
  }, [id]);

  if (product === undefined) return <Spinner />;
  if (product === null) return <p>Product not found.</p>;

  return (
    <div>
      <h2>{product.name}</h2>
      <PriceTag cents={product.priceCents} />
      <div>
        <button onClick={() => addItem(product)}>Add to cart</button>
      </div>
    </div>
  );
}
