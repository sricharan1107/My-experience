export default function Orders() {
  return (
    <div>
      <h2>Orders</h2>
      <p>No orders yet -- this is wired up once there's a real backend.</p>
    </div>
  );
}
