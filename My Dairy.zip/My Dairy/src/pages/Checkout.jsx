import { useCart } from '../hooks/useCart.js';

export default function Checkout() {
  const { items, clear } = useCart();
  const total = items.reduce((sum, i) => sum + i.priceCents * i.qty, 0);

  return (
    <div>
      <h2>Checkout</h2>
      <p>{items.length} item(s), total {(total / 100).toFixed(2)}</p>
      <button onClick={clear}>Place order (fake)</button>
    </div>
  );
}
