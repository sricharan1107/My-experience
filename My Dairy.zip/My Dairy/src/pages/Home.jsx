import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <div>
      <h1>shelfmark</h1>
      <p>A little storefront I'm building to learn React Router + context state.</p>
      <Link to="/products">Browse products &rarr;</Link>
    </div>
  );
}
