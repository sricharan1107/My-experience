import { useState } from 'react';
import { register } from '../services/authService.js';
import { useAuth } from '../hooks/useAuth.js';

export default function Register() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { signIn } = useAuth();

  async function handleSubmit(e) {
    e.preventDefault();
    const user = await register(email, password);
    signIn(user);
  }

  return (
    <form onSubmit={handleSubmit}>
      <h2>Create account</h2>
      <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="email" />
      <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" placeholder="password" />
      <button type="submit">Register</button>
    </form>
  );
}
