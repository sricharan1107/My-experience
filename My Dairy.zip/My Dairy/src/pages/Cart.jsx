import { Link } from 'react-router-dom';
import { useCart } from '../hooks/useCart.js';
import CartItem from '../components/CartItem.jsx';

export default function Cart() {
  const { items, removeItem } = useCart();

  if (items.length === 0) return <p>Your cart is empty.</p>;

  return (
    <div>
      <h2>Cart</h2>
      {items.map((item) => (
        <CartItem key={item.id} item={item} onRemove={removeItem} />
      ))}
      <Link to="/checkout">Proceed to checkout</Link>
    </div>
  );
}
