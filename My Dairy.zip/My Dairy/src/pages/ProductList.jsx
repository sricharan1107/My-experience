import { useState } from 'react';
import { useProducts } from '../hooks/useProducts.js';
import ProductCard from '../components/ProductCard.jsx';
import FilterSidebar from '../components/FilterSidebar.jsx';
import SearchBar from '../components/SearchBar.jsx';
import Spinner from '../components/Spinner.jsx';

export default function ProductList() {
  const { products, loading } = useProducts();
  const [category, setCategory] = useState(null);
  const [query, setQuery] = useState('');

  if (loading) return <Spinner />;

  const filtered = products.filter((p) => {
    if (category && p.category !== category) return false;
    if (query && !p.name.toLowerCase().includes(query.toLowerCase())) return false;
    return true;
  });

  return (
    <div style={{ display: 'flex', gap: 24 }}>
      <FilterSidebar selected={category} onSelect={setCategory} />
      <div style={{ flex: 1 }}>
        <SearchBar onSearch={setQuery} />
        <div className="product-grid">
          {filtered.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </div>
    </div>
  );
}
