import { useState } from 'react';
import { login } from '../services/authService.js';
import { useAuth } from '../hooks/useAuth.js';
import { isValidEmail } from '../utils/validators.js';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);
  const { signIn } = useAuth();

  async function handleSubmit(e) {
    e.preventDefault();
    if (!isValidEmail(email)) {
      setError('Enter a valid email');
      return;
    }
    const user = await login(email, password);
    signIn(user);
  }

  return (
    <form onSubmit={handleSubmit}>
      <h2>Login</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="email" />
      <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" placeholder="password" />
      <button type="submit">Login</button>
    </form>
  );
}
